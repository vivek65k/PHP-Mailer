<?php

require_once "vendor/autoload.php";

$mail = new PHPMailer\PHPMailer\PHPMailer();




$mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 4; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = true; // authentication enabled
$mail->SMTPSecure = 'tls'; // secure transfer enabled REQUIRED for Gmail
$mail->Host = "smtp.gmail.com";
// $mail->SMTPSecure = 'tls';
$mail->Port =465; // or 587
// $mail->Host = 'ssl://smtp.gmail.com:465';
$mail->IsHTML(true);
$mail->Username = "vivek65k@gmail.com";
$mail->Password = "vivek65kkumar";
$mail->SetFrom("vivek65k@gmail.com");
$mail->Subject = "Test";
$mail->Body = "hello";
$mail->AddAddress("vivek65k@gmail.com");

 if(!$mail->Send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
 } else {
    echo "Message has been sent";
 }